import { MessageCircle, Mail } from 'lucide-react';

const Footer = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-virelo-black text-white pt-24 pb-12">
      <div className="container mx-auto px-6">
        {/* Final CTA */}
        <div className="text-center mb-24">
          <h2 className="text-5xl md:text-7xl font-bold mb-10">Have Something <br />Worth Building?</h2>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-6">
            <a href="#contact" className="btn-primary bg-white text-virelo-black hover:bg-virelo-offwhite px-10 py-5 text-lg">
              Start a Project
            </a>
            <a 
              href="https://wa.me/919877541216" 
              target="_blank" 
              rel="noopener noreferrer" 
              className="flex items-center gap-3 text-xl font-medium hover:text-virelo-purple transition-colors"
            >
              <MessageCircle size={24} />
              WhatsApp Us
            </a>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-20 border-t border-white/10 pt-20">
          <div className="col-span-1 md:col-span-2">
            <img src="/VIRELO LOGO.png" alt="VIRELO" className="h-10 w-auto mb-8 brightness-0 invert" />
            <p className="text-white/50 max-w-sm text-lg leading-relaxed">
              VIRELO is an independent digital agency focused on building memorable brands and high-performance digital products.
            </p>
          </div>
          
          <div>
            <h4 className="text-lg font-bold mb-6">Explore</h4>
            <ul className="space-y-4 text-white/50">
              <li><a href="#services" className="hover:text-white transition-colors">Services</a></li>
              <li><a href="#work" className="hover:text-white transition-colors">Work</a></li>
              <li><a href="#about" className="hover:text-white transition-colors">About</a></li>
              <li><a href="#contact" className="hover:text-white transition-colors">Contact</a></li>
            </ul>
          </div>

          <div>
            <h4 className="text-lg font-bold mb-6">Connect</h4>
            <div className="flex gap-4">
              <a href="mailto:virelo.management@gmail.com" className="w-10 h-10 rounded-full border border-white/10 flex items-center justify-center hover:bg-white hover:text-virelo-black transition-all">
                <Mail size={18} />
              </a>
              <a href="https://wa.me/919877541216" className="w-10 h-10 rounded-full border border-white/10 flex items-center justify-center hover:bg-white hover:text-virelo-black transition-all">
                <MessageCircle size={18} />
              </a>
            </div>
          </div>
        </div>

        <div className="flex flex-col md:flex-row justify-between items-center border-t border-white/10 pt-12 text-white/30 text-sm">
          <p>© {currentYear} VIRELO. All rights reserved.</p>
          <div className="flex gap-8 mt-4 md:mt-0">
            <a href="#" className="hover:text-white">Privacy Policy</a>
            <a href="#" className="hover:text-white">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
