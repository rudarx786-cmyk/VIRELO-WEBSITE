import { motion } from 'framer-motion';

const About = () => {
  return (
    <section id="about" className="py-24 bg-white overflow-hidden">
      <div className="container mx-auto px-6">
        <div className="max-w-4xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <h2 className="text-4xl md:text-6xl font-bold mb-10 leading-tight">
              We are a human-first agency for the digital age.
            </h2>
            <p className="text-xl md:text-2xl text-virelo-black/60 leading-relaxed mb-12">
              At VIRELO, we believe that great digital experiences are built at the intersection of psychology and technology. We don't just build websites; we build ecosystems that help independent brands grow, evolve, and get remembered.
            </p>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
              <div>
                <div className="text-4xl font-bold text-virelo-purple mb-2">100%</div>
                <div className="text-sm text-virelo-black/50 uppercase tracking-widest font-semibold">Human Designed</div>
              </div>
              <div>
                <div className="text-4xl font-bold text-virelo-purple mb-2">24/7</div>
                <div className="text-sm text-virelo-black/50 uppercase tracking-widest font-semibold">Global Reach</div>
              </div>
              <div>
                <div className="text-4xl font-bold text-virelo-purple mb-2">1.8+</div>
                <div className="text-sm text-virelo-black/50 uppercase tracking-widest font-semibold">Years Exp.</div>
              </div>
              <div>
                <div className="text-4xl font-bold text-virelo-purple mb-2">Fast</div>
                <div className="text-sm text-virelo-black/50 uppercase tracking-widest font-semibold">Execution</div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default About;
