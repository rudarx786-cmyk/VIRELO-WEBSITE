import { motion } from 'framer-motion';
import { CheckCircle2 } from 'lucide-react';

const WhyVirelo = () => {
  const reasons = [
    'Direct communication with the designers and founders.',
    'No bloat, no fluff—just results-driven digital strategy.',
    'Deep expertise in modern web technologies and UX.',
    'Long-term partnership focused on your business growth.',
  ];

  const steps = [
    { name: 'Talk', desc: 'We start with a conversation to understand your goals and challenges.' },
    { name: 'Plan', desc: 'A strategic roadmap tailored to your specific market and audience.' },
    { name: 'Create', desc: 'Human-centric design meets high-performance engineering.' },
    { name: 'Launch', desc: 'Seamless deployment with rigorous testing and optimization.' },
    { name: 'Grow', desc: 'Continuous support and data-driven improvements to keep you ahead.' },
  ];

  return (
    <>
      <section className="py-24 bg-virelo-purple text-white overflow-hidden">
        <div className="container mx-auto px-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-20 items-center">
            <div>
              <h2 className="text-4xl md:text-5xl font-bold mb-8">Why VIRELO?</h2>
              <p className="text-xl text-white/70 mb-12">
                We are not just another agency. We are your extended digital team, committed to building brands that leave a lasting impression.
              </p>
              <div className="space-y-6">
                {reasons.map((reason, i) => (
                  <motion.div 
                    key={i} 
                    initial={{ opacity: 0, x: -20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: i * 0.1 }}
                    className="flex items-center gap-4"
                  >
                    <CheckCircle2 className="text-virelo-offwhite" />
                    <span className="text-lg">{reason}</span>
                  </motion.div>
                ))}
              </div>
            </div>
            <div className="relative">
              <div className="aspect-square rounded-3xl overflow-hidden">
                <img 
                  src="https://images.pexels.com/photos/3182763/pexels-photo-3182763.jpeg?auto=compress&cs=tinysrgb&w=800" 
                  alt="Team at work"
                  className="w-full h-full object-cover grayscale opacity-50"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      <section id="process" className="py-24 bg-white">
        <div className="container mx-auto px-6">
          <div className="text-center max-w-3xl mx-auto mb-20">
            <h2 className="text-4xl md:text-5xl font-bold mb-6">Our Process</h2>
            <p className="text-xl text-virelo-black/60">
              A streamlined, transparent approach to bringing your vision to life.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-5 gap-8">
            {steps.map((step, index) => (
              <motion.div
                key={step.name}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="relative group"
              >
                <div className="text-6xl font-bold text-virelo-purple/10 mb-6 group-hover:text-virelo-purple/20 transition-colors">
                  0{index + 1}
                </div>
                <h3 className="text-2xl font-bold mb-4">{step.name}</h3>
                <p className="text-virelo-black/60">{step.desc}</p>
                {index < steps.length - 1 && (
                  <div className="hidden lg:block absolute top-10 -right-4 w-8 h-[1px] bg-virelo-purple/20" />
                )}
              </motion.div>
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default WhyVirelo;
