import { motion } from 'framer-motion';

const projects = [
  {
    title: 'NOVA',
    category: 'Digital Experience / Web Design',
    image: 'https://images.pexels.com/photos/159299/graphic-design-studio-tracfone-programming-html-159299.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=800&w=1200',
  },
  {
    title: 'ARC',
    category: 'Branding / Identity',
    image: 'https://images.pexels.com/photos/9393252/pexels-photo-9393252.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=800&w=1200',
  },
  {
    title: 'LUMA',
    category: 'E-Commerce / Growth',
    image: 'https://images.pexels.com/photos/3183150/pexels-photo-3183150.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=800&w=1200',
  },
];

const Work = () => {
  return (
    <section id="work" className="py-24 bg-virelo-offwhite">
      <div className="container mx-auto px-6">
        <div className="flex flex-col md:flex-row justify-between items-baseline mb-16">
          <h2 className="text-4xl md:text-6xl font-bold mb-4">Selected Work</h2>
          <p className="text-virelo-black/60 max-w-md">
            A glimpse into the concepts and brands we've helped define and scale.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
          {projects.map((project, index) => (
            <motion.div
              key={project.title}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.2 }}
              className="group cursor-pointer"
            >
              <div className="overflow-hidden rounded-2xl mb-6 aspect-[4/5] bg-gray-200">
                <img
                  src={project.image}
                  alt={project.title}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                />
              </div>
              <h3 className="text-2xl font-bold mb-2">{project.title}</h3>
              <p className="text-virelo-purple font-medium uppercase tracking-wider text-sm">
                {project.category}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Work;
