import { motion } from 'framer-motion';
import { Palette, Globe, Megaphone, TrendingUp } from 'lucide-react';

const services = [
  {
    title: 'Web Design',
    description: 'High-converting, responsive websites that look stunning on any device and drive results.',
    icon: Globe,
  },
  {
    title: 'Branding',
    description: 'Distinctive visual identities and strategic positioning that define your brands soul.',
    icon: Palette,
  },
  {
    title: 'Digital Marketing',
    description: 'Data-driven campaigns across social and search to put your brand in front of the right eyes.',
    icon: Megaphone,
  },
  {
    title: 'Growth & Automation',
    description: 'Streamlining your workflows and scaling your systems for sustainable business growth.',
    icon: TrendingUp,
  },
];

const Services = () => {
  return (
    <section id="services" className="py-24 bg-white">
      <div className="container mx-auto px-6">
        <div className="flex flex-col md:flex-row justify-between items-end mb-16 gap-6">
          <div className="max-w-2xl">
            <h2 className="text-4xl md:text-5xl font-bold mb-6">Our Expertise</h2>
            <p className="text-xl text-virelo-black/60">
              We combine creative thinking with technical excellence to deliver digital solutions that perform.
            </p>
          </div>
          <div className="text-virelo-purple font-medium flex items-center gap-2 mb-2">
            View All Services <span className="text-2xl">→</span>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {services.map((service, index) => (
            <motion.div
              key={service.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="p-8 border border-virelo-purple/5 bg-virelo-offwhite/30 rounded-2xl hover:bg-virelo-purple hover:text-white transition-all group"
            >
              <service.icon className="w-12 h-12 mb-6 text-virelo-purple group-hover:text-white transition-colors" />
              <h3 className="text-2xl font-bold mb-4">{service.title}</h3>
              <p className="text-virelo-black/60 group-hover:text-white/80 transition-colors">
                {service.description}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Services;
