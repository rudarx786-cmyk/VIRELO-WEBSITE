import { motion } from 'framer-motion';
import { MessageCircle } from 'lucide-react';

const Hero = () => {
  return (
    <section className="relative min-h-screen flex items-center pt-20 overflow-hidden">
      {/* Background Banner */}
      <div className="absolute inset-0 z-0">
        <img 
          src="/VIRELO banner" 
          alt="VIRELO Hero Banner" 
          className="w-full h-full object-cover opacity-20"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-virelo-offwhite/50 via-virelo-offwhite to-virelo-offwhite" />
      </div>

      <div className="container mx-auto px-6 relative z-10">
        <div className="max-w-4xl">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
          >
            <span className="inline-block px-4 py-1.5 mb-6 text-sm font-semibold tracking-wider text-virelo-purple uppercase bg-virelo-purple/5 rounded-full">
              Independent Digital Agency
            </span>
            <h1 className="text-5xl md:text-8xl font-bold text-virelo-black leading-[1.1] mb-8">
              We Build Brands That <br className="hidden md:block" />
              <span className="text-virelo-purple">Get Remembered.</span>
            </h1>
            <p className="text-xl md:text-2xl text-virelo-black/70 mb-10 max-w-2xl leading-relaxed">
              Websites, branding and marketing built to make your business stand out in a crowded digital world.
            </p>

            <div className="flex flex-col sm:flex-row items-center gap-4">
              <a href="#contact" className="btn-primary w-full sm:w-auto">
                Start a Project
              </a>
              <a href="#work" className="btn-secondary w-full sm:w-auto">
                View Our Work
              </a>
              <a 
                href="https://wa.me/919877541216" 
                target="_blank" 
                rel="noopener noreferrer" 
                className="btn-whatsapp w-full sm:w-auto"
              >
                <MessageCircle size={20} />
                WhatsApp
              </a>
            </div>
          </motion.div>
        </div>
      </div>

      {/* Subtle Scroll Indicator */}
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1, duration: 1 }}
        className="absolute bottom-10 left-1/2 -translate-x-1/2 hidden md:block"
      >
        <div className="w-[1px] h-20 bg-virelo-purple/20 relative overflow-hidden">
          <motion.div 
            animate={{ y: [0, 80] }}
            transition={{ repeat: Infinity, duration: 1.5, ease: "easeInOut" }}
            className="absolute top-0 left-0 w-full h-1/2 bg-virelo-purple"
          />
        </div>
      </motion.div>
    </section>
  );
};

export default Hero;
