import { motion } from 'framer-motion';
import { Mail, MapPin, Send, MessageCircle } from 'lucide-react';

const Contact = () => {
  return (
    <section id="contact" className="py-24 bg-virelo-offwhite">
      <div className="container mx-auto px-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-20">
          <div>
            <h2 className="text-4xl md:text-6xl font-bold mb-8">Let's build something <br />great together.</h2>
            <p className="text-xl text-virelo-black/60 mb-12 max-w-lg">
              Ready to take your brand to the next level? Get in touch and let's start a conversation about your project.
            </p>

            <div className="space-y-8">
              <a href="mailto:virelo.management@gmail.com" className="flex items-center gap-6 group">
                <div className="w-14 h-14 rounded-full bg-virelo-purple/5 flex items-center justify-center group-hover:bg-virelo-purple group-hover:text-white transition-all">
                  <Mail size={24} />
                </div>
                <div>
                  <p className="text-sm text-virelo-black/50 uppercase tracking-widest font-semibold">Email Us</p>
                  <p className="text-xl font-medium">virelo.management@gmail.com</p>
                </div>
              </a>

              <a href="https://wa.me/919877541216" className="flex items-center gap-6 group">
                <div className="w-14 h-14 rounded-full bg-[#25D366]/10 text-[#25D366] flex items-center justify-center group-hover:bg-[#25D366] group-hover:text-white transition-all">
                  <MessageCircle size={24} />
                </div>
                <div>
                  <p className="text-sm text-virelo-black/50 uppercase tracking-widest font-semibold">WhatsApp</p>
                  <p className="text-xl font-medium">+91 9877541216</p>
                </div>
              </a>

              <div className="flex items-center gap-6 group">
                <div className="w-14 h-14 rounded-full bg-virelo-purple/5 flex items-center justify-center">
                  <MapPin size={24} />
                </div>
                <div>
                  <p className="text-sm text-virelo-black/50 uppercase tracking-widest font-semibold">Location</p>
                  <p className="text-xl font-medium">Jalandhar, Punjab</p>
                </div>
              </div>
            </div>
          </div>

          <motion.div 
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="bg-white p-10 rounded-3xl shadow-xl shadow-virelo-purple/5"
          >
            <form className="space-y-6" onSubmit={(e) => e.preventDefault()}>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-sm font-semibold uppercase tracking-wider text-virelo-black/50">Name</label>
                  <input type="text" className="w-full px-4 py-3 bg-virelo-offwhite rounded-lg focus:outline-none focus:ring-2 focus:ring-virelo-purple/20 transition-all" placeholder="John Doe" />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-semibold uppercase tracking-wider text-virelo-black/50">Email</label>
                  <input type="email" className="w-full px-4 py-3 bg-virelo-offwhite rounded-lg focus:outline-none focus:ring-2 focus:ring-virelo-purple/20 transition-all" placeholder="john@example.com" />
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-sm font-semibold uppercase tracking-wider text-virelo-black/50">Service</label>
                <select className="w-full px-4 py-3 bg-virelo-offwhite rounded-lg focus:outline-none focus:ring-2 focus:ring-virelo-purple/20 transition-all">
                  <option>Web Design</option>
                  <option>Branding</option>
                  <option>Digital Marketing</option>
                  <option>Growth & Automation</option>
                </select>
              </div>
              <div className="space-y-2">
                <label className="text-sm font-semibold uppercase tracking-wider text-virelo-black/50">Message</label>
                <textarea rows={4} className="w-full px-4 py-3 bg-virelo-offwhite rounded-lg focus:outline-none focus:ring-2 focus:ring-virelo-purple/20 transition-all" placeholder="Tell us about your project..."></textarea>
              </div>
              <button className="btn-primary w-full flex items-center justify-center gap-2">
                Send Message <Send size={18} />
              </button>
            </form>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default Contact;
