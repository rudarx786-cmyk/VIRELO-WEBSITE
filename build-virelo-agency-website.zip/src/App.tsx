import Navbar from './components/layout/Navbar';
import Hero from './components/sections/Hero';
import Services from './components/sections/Services';
import Work from './components/sections/Work';
import WhyVirelo from './components/sections/WhyVirelo';
import About from './components/sections/About';
import Contact from './components/sections/Contact';
import Footer from './components/layout/Footer';

function App() {
  return (
    <div className="min-h-screen">
      <Navbar />
      <main>
        <Hero />
        <Services />
        <Work />
        <WhyVirelo />
        <About />
        <Contact />
      </main>
      <Footer />
    </div>
  );
}

export default App;
